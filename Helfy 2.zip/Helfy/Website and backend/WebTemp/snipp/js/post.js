$('.monitary-button-submit').click(function() {
    console.log('Ajax triggered - Monitory');
    $.ajax({
        url: "https://helfy-angel-hacks.herokuapp.com/donation/clothes",
        type: "POST",
        dataType: "json",
        data: {
            name: $('#typeID').val(),
            contact: $('#fromID').val(),
            organisation: $('#toID').val(),
            location: $('#locID').val(),
            amount: $('#amID').val()
        }
    });
});