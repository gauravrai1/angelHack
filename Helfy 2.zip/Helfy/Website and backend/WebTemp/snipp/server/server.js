const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

// Initialize the app
const app = express();

// Body parser
app.use(bodyParser.json());

// Connect to database
const db = require('./config/config').mongoURI;

mongoose.connect(db, { useNewUrlParser: true })
.then(() => {
    console.log('MongoDB connected');
})
.catch(err => console.log(err));

// Routes
const donation = require('./routes/donation');
app.use('/donation', donation);
const organisation = require('./routes/organisation');
app.use('/organisation', organisation);

// Start port
const port = process.env.PORT || 1803;

app.listen(port, () => console.log('Server started on port ' + port));
