// Dependencies
const express = require('express');

// Import models
const Donation = require('../models/donation')
const Organisation = require('../models/organisation');

// Initialize router
const router = express.Router();

// Get requests
// Add
router.get('/add', (req, res) => {
    console.log('GET @ Add');
    res.status(200).json({ success: true });
});

// Organisation
router.get('/:id', (req, res) => {
    console.log('GET @ Organisation');
    Donation.find({ organisationId: req.params.id }, (err, transactions) => {
        if (!err) {
            res.status(200).json({ transactions, success: true });
        }
        else {
            console.log(err);
        }
    });
});

// Post requests
// Add
router.post('/add', (req, res) => {
    console.log('POST @ Add');
    const newOrganisation = new Organisation({
        name: req.body.name,
        address: req.body.location,
        donations: req.body.donations
    });
    newOrganisation
    .save()
    .then(newOrganisation => res.json({ newOrganisation }));
});

module.exports = router;
