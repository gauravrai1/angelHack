// Dependencies
const express = require('express');

// Import Models
const Donation = require('../models/donation');
const Organisation = require('../models/organisation');

// Initialize router
const router = express.Router();

// Get requests
// Clothes
router.get('/clothes', (req, res) => {
    console.log('GET @ Clothes');
    res.status(200).json({ success: true });
});

// Donation
router.get('/:id', (req, res) => {
    console.log('GET @ Transaction');
    Donation.findById(req.params.id, (err, transaction) => {
        if (!err) {
            res.status(200).json({ transaction, success: true });
        }
        else {
            console.log(err);
        }
    });
});

// Food
router.get('/food', (req, res) => {
    console.log('GET @ Food');
    res.status(200).json({ success: true });
});

// Monitary
router.get('/monitary', (req, res) => {
    console.log('GET @ Monitary');
    res.status(200).json({ success: true });
});

// Others
router.get('/other', (req, res) => {
    console.log('GET @ Others');
    res.status(200).json({ success: true });
});

// Post requests
// Clothes
router.post('/clothes', (req, res) => {
    console.log('POST @ Monitary\n' + req.body.organisation);
    console.log('Success');
    Organisation.findOne({ name: req.body.organisation }, (err, organisation) => {
        if (!err) {
            const newDonation = new Donation({
                donarName: req.body.name,
                donarContact: req.body.contact,
                donationType: 'CLOTHES',
                location: req.body.location,
                organisationId: organisation._id,
                description: 'NULL',
                amount: rew.body.amount
            });
            newDonation
            .save()
            .then(newDonation => res.json(newDonation));
        }
        else {
            console.log(err);
        }
    });
});

// Donation approval
router.post('/:id/:status', (req, res) => {
    console.log('POST @ Donation approval');
    console.log(req.params.id + '\n' + req.params.status);
    Donation.update({ _id: req.params.id }, { $set: { status: req.params.status.toUpperCase() } }, (err) => {
        if (!err) {
            Donation.findById(req.params.id, (err, transaction) => {
                if (!err) {
                    res.json({ transaction, success: true });
                }
            });
        }
        else {
            console.log(err);
        }
    });
});

// Food
router.post('/food', (req, res) => {
    console.log('POST @ Food\n' + req.body.organisation);
    console.log('Success');
    Organisation.findOne({ name: req.body.organisation }, (err, organisation) => {
        if (!err) {
            const newDonation = new Donation({
                donarName: req.body.name,
                donarContact: req.body.contact,
                donationType: 'FOOD',
                location: req.body.location,
                organisationId: organisation._id,
                description: req.body.desc,
                amount: 0
            });
            newDonation
            .save()
            .then(newDonation => res.json(newDonation));
        }
        else {
            console.log(err);
        }
    });
})

// Monitary
router.post('/monitary', (req, res) => {
    console.log('POST @ Monitary\n' + req.body.organisation);
    console.log('Success');
    Organisation.findOne({ name: req.body.organisation }, (err, organisation) => {
        if (!err) {
            const newDonation = new Donation({
                donarName: req.body.name,
                donarContact: req.body.contact,
                donationType: 'MONITARY',
                location: req.body.location,
                organisationId: organisation._id,
                description: 'MONITARY',
                amount: req.body.amount
            });
            newDonation
            .save()
            .then(newDonation => res.json(newDonation));
        }
        else {
            console.log(err);
        }
    });
});

// Others
router.post('/other', (req, res) => {
    console.log('POST @ Others\n' + req.body.organisation);
    console.log('Success');
    Organisation.findOne({ name: req.body.organisation }, (err, organisation) => {
        if (!err) {
            const newDonation = new Donation({
                donarName: req.body.name,
                donarContact: req.body.contact,
                donationType: 'OTHER',
                location: req.body.location,
                organisationId: organisation._id,
                description: req.body.desc,
                amount: req.body.amount
            });
            newDonation
            .save()
            .then(newDonation => res.json(newDonation));
        }
        else {
            console.log(err);
        }
    });
});

module.exports = router;
