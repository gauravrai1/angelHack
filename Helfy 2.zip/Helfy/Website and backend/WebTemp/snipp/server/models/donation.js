const mongoose = require('mongoose');

const donationSchema = mongoose.Schema({
    donarName: String,
    donarContact: String,
    donationType: String,
    location: String,
    organisationId: String,
    description: String,
    amount: {
        type: Number,
        default: 0
    },
    status: {
        type: String,
        default: 'PENDING'
    },
    date: {
        type: Date,
        default: Date.now
    }
});

const Donation = module.exports = mongoose.model('Donation', donationSchema);
