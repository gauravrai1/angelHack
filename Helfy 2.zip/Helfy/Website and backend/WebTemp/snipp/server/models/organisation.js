const mongoose = require('mongoose');

const organisationSchema = mongoose.Schema({
    name: String,
    address: String,
    totalDonation: {
        type: Number,
        default: 0
    }
});

const Organisation = module.exports = mongoose.model('Organisation', organisationSchema);
