module.exports = {
    mongoURI: 'mongodb://admin:qwerty123456@ds149146.mlab.com:49146/ah-helfy'
}
