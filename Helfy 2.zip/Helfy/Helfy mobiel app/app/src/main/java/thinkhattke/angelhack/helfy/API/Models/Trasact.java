package thinkhattke.angelhack.helfy.API.Models;

import com.google.gson.annotations.SerializedName;

public class Trasact {

    @SerializedName("amount")
    private String amount;

    @SerializedName("status")
    private String status;

    @SerializedName("_id")
    private String _id;

    @SerializedName("donarName")
    private String donarName;

    @SerializedName("donarContact")
    private String donarContact;

    @SerializedName("donationType")
    private String donationType;

    @SerializedName("organisationId")
    private String organisationId;

    @SerializedName("location")
    private String location;

    @SerializedName("description")
    private String description;

    @SerializedName("date")
    private boolean date;


    public Trasact(String amount, String status, String _id, String donarName, String donarContact, String donationType, String organisationId, String location, String description, boolean date) {
        this.amount = amount;
        this.status = status;
        this._id = _id;
        this.donarName = donarName;
        this.donarContact = donarContact;
        this.donationType = donationType;
        this.organisationId = organisationId;
        this.location = location;
        this.description = description;
        this.date = date;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getDonarName() {
        return donarName;
    }

    public void setDonarName(String donarName) {
        this.donarName = donarName;
    }

    public String getDonarContact() {
        return donarContact;
    }

    public void setDonarContact(String donarContact) {
        this.donarContact = donarContact;
    }

    public String getDonationType() {
        return donationType;
    }

    public void setDonationType(String donationType) {
        this.donationType = donationType;
    }

    public String getOrganisationId() {
        return organisationId;
    }

    public void setOrganisationId(String organisationId) {
        this.organisationId = organisationId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isDate() {
        return date;
    }

    public void setDate(boolean date) {
        this.date = date;
    }

}
