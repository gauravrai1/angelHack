package thinkhattke.angelhack.helfy.API.Services;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.PATCH;
import retrofit2.http.POST;
import retrofit2.http.Path;
import thinkhattke.angelhack.helfy.API.Models.Order;
import thinkhattke.angelhack.helfy.API.Models.Trasact;

public interface ApiInterface {

    @GET("organisation/{organisationid}/")
    Call<Order> getOrders(@Path(value = "organisationid",
            encoded = true) String organisationid);

    @POST("{donationid}/ACCEPTED")
    Call<Order> accepted(@Path(value = "donationid",
            encoded = true) String donationid);

    @POST("{donationid}/REJECTED")
    Call<Order> rejected(@Path(value = "donationid",
            encoded = true) String donationid);


}
