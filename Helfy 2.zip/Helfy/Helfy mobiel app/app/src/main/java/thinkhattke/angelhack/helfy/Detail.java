package thinkhattke.angelhack.helfy;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import java.lang.reflect.Type;
import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import thinkhattke.angelhack.helfy.API.Models.Order;
import thinkhattke.angelhack.helfy.API.Services.APIClient;
import thinkhattke.angelhack.helfy.API.Services.ApiInterface;
import thinkhattke.angelhack.helfy.DB.TinyDB;

public class Detail extends AppCompatActivity {

    CircleImageView pic;

    TextView statusText, addresstext, typetext, itemtext, emailtext, mobiletext, nametext;

    RelativeLayout itemBox;

    String name, status, mobile, type, item, orgid, id, description;

    LinearLayout statusBox;

    Button accept, reject;

    TinyDB db;

    ApiInterface api;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Donation Info");
        setSupportActionBar(toolbar);toolbar.setTitleTextColor(getResources().getColor(R.color.white));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.backpress_white_icon);

        pic = findViewById(R.id.image);
        nametext = findViewById(R.id.name);
        statusText = findViewById(R.id.status);
        addresstext = findViewById(R.id.address);
        typetext = findViewById(R.id.type);
        mobiletext = findViewById(R.id.mobile);
        itemtext = findViewById(R.id.item);
        emailtext = findViewById(R.id.email);
        accept = findViewById(R.id.accept);
        reject = findViewById(R.id.reject);
        statusBox = findViewById(R.id.statusBox);
        itemBox = findViewById(R.id.itemBox);

        statusBox.setVisibility(View.GONE);

        //Initialising Retrofit Interface
        api = APIClient.getClient().create(ApiInterface.class);

        db = new TinyDB(Detail.this);

        Picasso.with(this)
                .load("https://media.licdn.com/dms/image/C5103AQHaNYg27NW5HA/profile-displayphoto-shrink_100_100/0?e=1562198400&v=beta&t=XA6kX1MhuzVXqyQPvmFdfGFrjlrcgeyPEumim3JQEP8")
                .error(R.drawable.user_icon)
                .placeholder(R.drawable.user_icon)
                .into(pic);

        final Bundle bundle = getIntent().getExtras();

        assert bundle != null;
        String key;

        name = db.getString("name");
        id = db.getString("donationID");
        status = db.getString("status");
        mobile = db.getString("contact");
        description = db.getString("description");

        nametext.setText(name);
        statusText.setText(status);
        mobiletext.setText(mobile);
        typetext.setText("Health");
        addresstext.setText("Chennai");
        itemtext.setText("Donation");

        if (statusText.getText().equals("PENDING")){
            statusBox.setVisibility(View.VISIBLE);
        }

        accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateStatus("Accepted");
                statusText.setText("Accepted");
            }
        });

        reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateStatus("Rejected");
                statusText.setText("Rejected");
            }
        });

    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();

        Intent i = new Intent(Detail.this, Home.class);
        startActivity(i);
        finish();

    }

    private void updateStatus(String status) {

        if (status.equals("Accepted")) {

            api.accepted(id).enqueue(new Callback<Order>() {
                @Override
                public void onResponse(Call<Order> call, Response<Order> response) {
                    print("This request is accepted, contact of the donor is email along with the instructions");
                    statusBox.setVisibility(View.GONE);
                }

                @Override
                public void onFailure(Call<Order> call, Throwable t) {

                }
            });

        } else {

            api.rejected(id).enqueue(new Callback<Order>() {
                @Override
                public void onResponse(Call<Order> call, Response<Order> response) {
                    print("This request is rejected, It will be forwarded to other organisation");
                    statusBox.setVisibility(View.GONE);
                }

                @Override
                public void onFailure(Call<Order> call, Throwable t) {

                }
            });

        }

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    public void print(String s) {
        Toast.makeText(Detail.this, s, Toast.LENGTH_SHORT).show();
    }

}
