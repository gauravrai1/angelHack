package thinkhattke.angelhack.helfy;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.util.SortedList;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.GestureDetector;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import thinkhattke.angelhack.helfy.API.Models.Trasact;
import thinkhattke.angelhack.helfy.API.Services.APIClient;
import thinkhattke.angelhack.helfy.API.Services.ApiInterface;
import thinkhattke.angelhack.helfy.Adapter.OrdersAdapter;
import thinkhattke.angelhack.helfy.API.Models.Order;

public class Home extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    RecyclerView recyclerView;

    LinearLayoutManager linearLayoutManager;

    OrdersAdapter adapter;

    ProgressDialog progressDialog;
    ApiInterface api;
    private List<Trasact> transaction;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        recyclerView = findViewById(R.id.recyclerview);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("My Dashboard");
        toolbar.setTitleTextColor(getResources().getColor(R.color.white));
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        //Initialising Retrofit Interface
        api = APIClient.getClient().create(ApiInterface.class);

        request();

    }

    public void request() {

        api.getOrders("5cc4c5838288db2efcafecd8").enqueue(new Callback<Order>() {

            @Override
            public void onResponse(Call<Order> call, retrofit2.Response<Order> response) {

                Order order = response.body();
                transaction = order.getTrasacts();

                setRecyclerView();

            }

            @Override
            public void onFailure(Call<Order> call, Throwable t) {


                print("Something Wen't Wrong");

            }
        });

    }

    //Setup RecyclerView
    private void setRecyclerView() {


        //Setting Layout Manager
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(Home.this);
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);


        //Setting up the Adapter
        adapter = new OrdersAdapter(Home.this);


        //Adding data to Adapter
        adapter.setListContent(transaction);


        //Setting adapter to the recyclerView
        recyclerView.setAdapter(adapter);


        //fade In animation
        recyclerView.animate().alpha(1f).setDuration(500);


        //Setting empty animation logic
        if (transaction.size() == 0) {

            recyclerView.setVisibility(View.GONE);


        } else {

            recyclerView.setVisibility(View.VISIBLE);

        }


    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        switch(id){
            case R.id.social_media_item:
//                Intent intent1 = new Intent(Home.this, SocialMedia.class);
//                startActivity(intent1);
//                finish();
                break;
            case R.id.statistics_item:
//                Intent i = new Intent(Home.this, Statistics.class);
//                startActivity(i);
//                finish();
                break;
            case R.id.funds_item:
//                Intent intent = new Intent(Home.this, Funds.class);
//                startActivity(intent);
//                finish();
                break;
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void print(String s) {
        Toast.makeText(Home.this, s, Toast.LENGTH_SHORT).show();
    }

}
