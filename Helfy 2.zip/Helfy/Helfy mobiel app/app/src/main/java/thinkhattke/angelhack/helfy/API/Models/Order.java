package thinkhattke.angelhack.helfy.API.Models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Order {

    @SerializedName("transactions")
    private List<Trasact> trasacts;

    public List<Trasact> getTrasacts() {
        return trasacts;
    }

    public void setTrasacts(List<Trasact> trasacts) {
        this.trasacts = trasacts;
    }
}
